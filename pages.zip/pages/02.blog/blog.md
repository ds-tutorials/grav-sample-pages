---
title: Blog
media_order: milky-way.png
hero_classes: text-light
hero_image: milky-way.png
content:
    items:
        - '@self.children'
    limit: 5
    order:
        by: date
        dir: desc
    pagination: true
    url_taxonomy_filters: true
feed:
    limit: 10
---

# My Example Blog

## Learning to use Grav